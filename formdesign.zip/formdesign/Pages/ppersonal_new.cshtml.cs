using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace formdesign.Pages
{
    public class ppersonal_newModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
